<?php

  class fecalysis extends module{
  
    function fecalysis(){
      $this->author = 'darth_ali';
      $this->version = "0.1".date("Y-m-d");
      $this->module = "fecalysis";
      $this->description = "CHITS Module - Fecalysis Examination";    
    }
    
    
    // ----- STANDARD MODULE FUNCTIONS ------ 
    
    function init_deps(){
      module::set_dep($this->module,"module");
      module::set_dep($this->module,"lab");      
    }
    
    function init_lang(){
      module::set_lang("FTITLE_FECALYSIS","english","FECALYSIS LAB EXAM","Y");
      module::set_lang("FTITLE_FECALYSIS_MACRO","english","Macroscopic","Y");      
      module::set_lang("FTITLE_FECALYSIS_MICRO","english","Microscopic","Y");       
      module::set_lang("THEAD_MACRO_PHYSICAL","english","PHYSICAL","Y");     
      module::set_lang("THEAD_MACRO_CHEMICAL","english","CHEMICAL","Y");     
      module::set_lang("LBL_MACRO_COLOR","english","Color","Y");
      module::set_lang("LBL_MACRO_CONSISTENCY","english","Consistency","Y");
      module::set_lang("LBL_MACRO_OCCULTBLOOD","english","Occult Blood","Y");
      module::set_lang("LBL_MACRO_OCCULTBLOOD","english","Occult Blood","Y");
      module::set_lang("LBL_MICRO_OVA","english","Ova or Parasite","Y");
      module::set_lang("LBL_MICRO_WBC","english","WBC","Y");
      module::set_lang("LBL_MICRO_WBC","english","WBC","Y");
      module::set_lang("LBL_MICRO_RBC","english","RBC","Y");
      module::set_lang("LBL_MICRO_BACTERIA","english","Bacteria","Y");
      module::set_lang("LBL_MICRO_FAT","english","Fat Globules","Y");
      module::set_lang("LBL_MICRO_STARCH","english","Starch Granules","Y");
      module::set_lang("LBL_MICRO_OTHERS","english","OTHERS","Y");
      module::set_lang("LBL_MICRO_OTHERS","english","OTHERS","Y");      
      module::set_lang("LBL_MICRO_REMARKS","english","REMARKS","Y");                                          
    }
    
    function init_stats(){    
    }
    
    
    
    function init_help(){
    
    }
    
        
    function init_menu(){
      if(func_num_args()>0):
        $arg_list = func_get_args();
      endif;
      
      module::set_detail($this->description,$this->version,$this->author,$this->module);      
    }
    
    function init_sql(){
      if(func_num_args()>0):
        $arg_list = func_get_args();
      endif;
      
      module::execsql("CREATE TABLE IF NOT EXISTS `m_consult_lab_fecalysis` (
        `consult_id` float NOT NULL,`request_id` float NOT NULL,`patient_id` float NOT NULL,
        `date_lab_exam` date NOT NULL,`fecal_color` text NOT NULL,`fecal_consistency` text NOT NULL,
        `fecal_occultblood` text NOT NULL,`fecal_ova` text NOT NULL,`fecal_wbc` text NOT NULL,
        `fecal_rbc` text NOT NULL,`fecal_bacteria` text NOT NULL,`fecal_fat` text NOT NULL,
        `fecal_starch` text NOT NULL,`fecal_others` text NOT NULL,`release_flag` text NOT NULL,
        `user_id` float NOT NULL
      ) ENGINE=MyISAM DEFAULT CHARSET=latin1;");                  
    }
    
    function drop_tables(){
      module::execsql("DROP TABLE `m_consult_lab_fecalysis`;");
    }
    
    //----- CUSTOM MODULE FUNCTIONS -----
    
    
    function _consult_lab_fecalysis(){
      if(func_num_args()>0):
        $arg_list = func_get_args();
        $menu_id = $arg_list[0];
        $post_vars = $arg_list[1];
        $get_vars = $arg_list[2];
        $validuser = $arg_list[3];
        $isadmin = $arg_list[4];      
      endif;
      
      if($exitinfo=$this->missing_dependencies('fecalysis')):
        return print($exitinfo);      
      endif;
      
      $f = new fecalysis;
      
      if($_POST["submitlab"]):
      
      endif;
      
      $f->form_consult_lab_fecalysis($menu_id,$post_vars,$get_vars);
    }
    
    
    function form_consult_lab_fecalysis(){
      if(func_num_args()>0):
        $arg_list = func_get_args();
        $menu_id = $arg_list[0];
        $post_vars = $arg_list[1];
        $get_vars = $arg_list[2];
        $validuser = $arg_list[3];
        $isadmin = $arg_list[4];      
      endif;      
      
      
      
      echo "<table>";
      echo "<tr colspan='2'><thead>FTITLE_FECALYSIS_MACRO</thead></tr>";
      echo "<tr><td>THEAD_MACRO_PHYSICAL</td><td>THEAD_MACRO_CHEMICAL</td></tr>";
      
      
    
      echo "</table>";
    }
    
    
    
  
  
  
  
  
  }
?>