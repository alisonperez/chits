<?php


  class demographic_profile extends module{
    
    function demographic_profile(){
      $this->author = 'darth_ali';
      $this->module = "demographic_profile";
      $this->version = "0.1-".date("Y-m-d");
      $this->description = "CHITS Module - Demographics profile";    
    }
    
    
    function init_deps(){
      module::set_dep($this->module,"module");      
    }
    
    function init_lang(){
    
    }
    
    function init_stats(){
    
    }
  
  
  function init_menu() {
          // use this for updating menu system
          // under LIBRARIES
      if (func_num_args()>0) {
        $arg_list = func_get_args();
      }
          
          // _<modulename> in SQl refers to function _<modulename>() below
          // _demographic_profile in SQL refers to function _demographic_profile() below;
            
      module::set_menu($this->module, "Demographic Profile", "LIBRARIES", "_demographic_profile");
                                                                              
          // put in more details      
      module::set_detail($this->description, $this->version, $this->author, $this->module);
  }
                                                                                                              
        
    function init_help(){
    
    }
    
    function init_sql(){
      module::execsql("CREATE TABLE IF NOT EXISTS `m_lib_demographic_profile` (
        `demographic_id` int(3) NOT NULL,`year` year(4) NOT NULL,`barangay` int(10) NOT NULL,`bhs` int(11) NOT NULL,`doctors_male` int(3) NOT NULL,
        `doctors_female` int(3) NOT NULL,`dentist_male` int(3) NOT NULL,`dentist_female` int(3) NOT NULL,`nurse_male` int(3) NOT NULL,
        `nurse_female` int(3) NOT NULL,`midwife_male` int(3) NOT NULL,`midwife_female` int(3) NOT NULL,`nutritionist_male` int(3) NOT NULL,
        `nutritionist_female` int(3) NOT NULL,`medtech_male` int(3) NOT NULL,`medtech_female` int(3) NOT NULL,`se_male` int(3) NOT NULL,
        `se_female` int(3) NOT NULL,`si_male` int(3) NOT NULL,`si_female` int(3) NOT NULL,`bhw_male` int(3) NOT NULL,`bhw_female` int(3) NOT NULL
        ) ENGINE=MyISAM DEFAULT CHARSET=latin1;");                
    }
    
    function drop_tables(){
      module::execsql("DROP TABLE `m_lib_demographic_profile`");
    }
    
    // ----- CUSTOM MODULE FUNCTIONS -----
  
  
    function _demographic_profile(){
      echo "alison";    
    }
  }

?>