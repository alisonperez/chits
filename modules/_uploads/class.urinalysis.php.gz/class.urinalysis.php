<?php

  class urinalysis extends module{
  
  
  
    function urinalysis(){
      $this->author = "darth_ali";
      $this->module = "urinalysis";
      $this->version = "0.1-".date("Y-m-d");
      $this->description = "CHITS Module - Urinalysis Examination";    
      
      $this->color = array('Yellow','Pale Yellow','Dark Yellow','Amber','Straw');
      $this->reacton = array('Acidic','Alkaline','Neutral');
      $this->transparency = array('Clear','St. Turbid','Turbid','Very Turbid');
      $this->gravity = array('1:000','1:005','1:010','1:015','1:020','1:025','1:030');
      $this->ph = array('5.0','6.0','6.5','7.0','7.5','8.0');
      
      $this->albumin = array('Negative','Positive','+','++','+++','++++');
      $this->sugar = array('Negative','Positive','+','++','+++','++++');      
      $this->pregnancy = array('Negative','Positive','Doubtful');      
    }
    
    // ----- STANDARD MODULE FUNCTIONS -----
    
    function init_deps(){
      module::set_dep($this->module,"module");
      module::set_dep($this->module,"lab");    
    }              
    
    
    function init_lang(){
    
    }
    
    function init_stats(){
    
    }
    
    function init_help(){
    
    
    }
    
    function init_menu(){
      if(func_num_args()>0):
        $arg_list = func_get_args();
      endif;
      
      module::set_detail($this->description,$this->version,$this->author,$this->module);
    }
    
    function init_sql(){
	module::execsql("CREATE TABLE IF NOT EXISTS `m_consult_lab_urinalysis` (
	  `consult_id` float NOT NULL,`request_id` float NOT NULL,`patient_id` float NOT NULL,`date_lab_exam` date NOT NULL,
	  `physical_color` text NOT NULL,`physical_reaction` text NOT NULL,`physical_transparency` text NOT NULL,`physical_gravity` text NOT NULL,
	  `physical_ph` text NOT NULL,`chem_albumin` varchar(10) NOT NULL,`chem_sugar` varchar(10) NOT NULL,`chem_pregnancy` varchar(10) NOT NULL,
	  `sediments_rbc` text NOT NULL,`sediments_pus` text NOT NULL,`sediments_epithelial` text NOT NULL,`sediments_urates` text NOT NULL,
	  `sediments_calcium` text NOT NULL,`sediments_fat` text NOT NULL,`sediments_phosphate` text NOT NULL,`sediments_uric` text NOT NULL,
	  `sediments_amorphous` text NOT NULL,`sediments_carbonates` text NOT NULL,`sediments_bacteria` text NOT NULL,
	  `sediments_mucus` text NOT NULL,`cast_coarsely` text NOT NULL,`cast_pus` text NOT NULL,`cast_hyaline` text NOT NULL,
	  `cast_finely` text NOT NULL,`cast_redcell` text NOT NULL,`cast_waxy` text NOT NULL,`release_flag` text NOT NULL,
	  `release_date` date NOT NULL,`user_id` int(11) NOT NULL
	) ENGINE=MyISAM DEFAULT CHARSET=latin1");    
    }
    
    function drop_tables(){
    	module::execsql("DROP TABLE m_consult_lab_urinalysis");
    
    }
    

    // --- CUSTOM-BUILT FUNCTIONS ---
    
    function _consult_lab_urinalysis(){
      if(func_num_args()>0):
        $arg_list = func_get_args();
        $menu_id = $arg_list[0];
        $post_vars = $arg_list[1];
        $get_vars = $arg_list[2];  
        $validuser = $arg_list[3];
        $isadmin = $arg_list[4];      
      endif;
                                                                  
      if($exitinfo=$this->missing_dependencies('urinalysis')):
        return print($exitinfo);
      endif;
                                                                                      
      $u = new urinalysis;
      
      if($_POST["submitlab"]):
                    
      endif;
      
      $u->form_consult_lab_urinalysis($menu_id,$post_vars,$get_vars);
      
                                                                                            
    
    }
    
    function _consult_lab_urinalysis_result(){
    
    }
    
    function form_consult_lab_urinalysis(){
      if(func_num_args()>0):
        $arg_list = func_get_args();
        $menu_id = $arg_list[0];
        $post_vars = $arg_list[1];
        $get_vars = $arg_list[2]; 
        $validuser = $arg_list[3];
        $isadmin = $arg_list[4];  
      endif;
      
      echo "<form action='$_SERVER[PHP_SELF]?page=$_GET[page]&menu_id=$_GET[menu_id]&consult_id=$_GET[consult_id]&ptmenu=$_GET[ptmenu]&module=$_GET[module]&request_id=$_GET[request_id]#$_GET'.'_form' method='POST' name='form_lab'>";
      echo "<table border='1'>";
      echo "<tr><td colspan='2'>URINALYSIS</td></tr>";
      echo "<tr><td>PHYSICAL APPEARANCE</td><td>QUANT. CHEMICAL TEST</td></tr>";
      echo "<tr>";
      echo "<td>";
      echo "COLOR&nbsp;<select name='sel_color' value='1'>";
      
      //foreach($this->color as $key=>$value){
        
      //}
      
      echo "</select>";
      echo "</td>";
      
      echo "</tr>";
      echo "</table>";
      echo "</form>";
                                                
    
    }
    
  
  
  
  }
?>
